/******************************************************************************
* Copyright (c) 2009 - 2020 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/


#include <stdlib.h>
#include <yfuns.h>
#include "xil_types.h"

void exit(sint32 arg)
{
  while(1) {
	;
  }
}
